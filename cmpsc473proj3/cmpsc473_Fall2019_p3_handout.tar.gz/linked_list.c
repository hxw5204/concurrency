#include "linked_list.h"

// Create and return a new list
list_t* list_create()
{
	/* IMPLEMENT THIS IF YOU WANT TO USE LINKED LISTS */
}

// Destroy a list
void list_destroy(list_t* list)
{
	/* IMPLEMENT THIS IF YOU WANT TO USE LINKED LISTS */
}

// Return the number of elements in the list
size_t list_count(list_t* list)
{
	/* IMPLEMENT THIS IF YOU WANT TO USE LINKED LISTS */
}

// Find the first node in the list with the given data
// Returns NULL if data could not be found
list_node_t* list_find(list_t* list, void* data)
{
	/* IMPLEMENT THIS IF YOU WANT TO USE LINKED LISTS */
}

// Insert a new node in the list with the given data
void list_insert(list_t* list, void* data)
{
	/* IMPLEMENT THIS IF YOU WANT TO USE LINKED LISTS */
}

// Remove a node from the list and free the node resources
void list_remove(list_t* list, list_node_t* node)
{
	/* IMPLEMENT THIS IF YOU WANT TO USE LINKED LISTS */
}

// Execute a function for each element in the list
void list_foreach(list_t* list, void (*func)(void* data))
{
	/* IMPLEMENT THIS IF YOU WANT TO USE LINKED LISTS */
}
